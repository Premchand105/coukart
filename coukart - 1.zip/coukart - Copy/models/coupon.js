// models/coupon.js
const DataStore = require('../data-store');
const couponsStore = new DataStore('coupons.json');

class Coupon {
  constructor(data) {
    this.title = data.title;
    this.code = data.code;
    this.price = data.price;
    this.category = data.category;
    this.sold = data.sold || false;
    this.seller = data.seller || 'anonymous';
    this.expiryDate = data.expiryDate;
    this.createdAt = data.createdAt || new Date().toISOString();
    this._id = data._id;
  }

  // Save a new coupon
  async save() {
    // Validate required fields
    if (!this.title || !this.code || this.price === undefined || !this.category) {
      throw new Error('Missing required fields');
    }
    
    // Check if code already exists
    const existingCoupons = await couponsStore.find({ code: this.code });
    if (existingCoupons.length > 0) {
      throw new Error('Coupon code already exists');
    }
    
    const insertedCoupon = await couponsStore.insert(this);
    // Update the current instance with any additional fields from the store
    Object.assign(this, insertedCoupon);
    return this;
  }

  // Find coupon by ID
  static async findById(id) {
    const coupon = await couponsStore.findById(id);
    if (!coupon) return null;
    return new Coupon(coupon);
  }

  // Find coupons by query
  static async find(query) {
    const coupons = await couponsStore.find(query);
    return coupons.map(coupon => new Coupon(coupon));
  }

  // Update a coupon
  async update() {
    const result = await couponsStore.updateOne(
      { _id: this._id },
      { $set: {
        title: this.title,
        code: this.code,
        price: this.price,
        category: this.category,
        sold: this.sold,
        seller: this.seller,
        expiryDate: this.expiryDate
      }}
    );
    
    if (result.modifiedCount === 0) {
      throw new Error('Coupon not found or not updated');
    }
    
    // Update this instance with the updated data
    Object.assign(this, result.updatedItem);
    return this;
  }
}

module.exports = Coupon;
