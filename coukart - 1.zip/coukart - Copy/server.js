const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const Coupon = require('./models/coupon');

// Initialize express app
const app = express();
const PORT = process.env.PORT || 8080;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Routes
// Get all coupons
app.get('/api/coupons/all', async (req, res) => {
    try {
        // Only return coupons that are not sold
        const coupons = await Coupon.find({ sold: false });
        res.json(coupons);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Sell a coupon
app.post('/api/coupons/sell', async (req, res) => {
    try {
        const coupon = new Coupon(req.body);
        await coupon.save();
        res.status(201).json(coupon);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Buy a coupon
app.post('/api/coupons/buy/:id', async (req, res) => {
    try {
        const coupon = await Coupon.findById(req.params.id);
        
        if (!coupon) {
            return res.status(404).json({ error: 'Coupon not found' });
        }
        
        if (coupon.sold) {
            return res.status(400).json({ error: 'Coupon already sold' });
        }
        
        coupon.sold = true;
        await coupon.update();
        
        res.json({ message: 'Coupon purchased successfully', coupon });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get coupons by category
app.get('/api/coupons/category/:category', async (req, res) => {
    try {
        const coupons = await Coupon.find({ 
            category: req.params.category,
            sold: false
        });
        res.json(coupons);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Search coupons
app.get('/api/coupons/search', async (req, res) => {
    try {
        const { query } = req.query;
        const allCoupons = await Coupon.find({ sold: false });
        
        // Filter coupons using JavaScript string methods instead of MongoDB query
        const coupons = allCoupons.filter(coupon => {
            return coupon.title.toLowerCase().includes(query.toLowerCase()) || 
                   coupon.category.toLowerCase().includes(query.toLowerCase());
        });
        
        res.json(coupons);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Serve the main HTML file for all other routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
