// data-store.js
const fs = require('fs').promises;
const path = require('path');

class DataStore {
  constructor(filename) {
    this.filename = filename;
    this.data = [];
    this.loaded = false;
  }

  async load() {
    try {
      const dataDir = path.join(__dirname, 'data');
      const filePath = path.join(dataDir, this.filename);
      
      // Create data directory if it doesn't exist
      try {
        await fs.mkdir(dataDir, { recursive: true });
      } catch (err) {
        if (err.code !== 'EEXIST') throw err;
      }
      
      // Try to read the file
      try {
        const fileData = await fs.readFile(filePath, 'utf8');
        this.data = JSON.parse(fileData);
      } catch (err) {
        if (err.code === 'ENOENT') {
          // File doesn't exist yet, create it with empty array
          await fs.writeFile(filePath, JSON.stringify([]));
          this.data = [];
        } else {
          throw err;
        }
      }
      
      this.loaded = true;
      return this.data;
    } catch (error) {
      console.error(`Error loading data from ${this.filename}:`, error);
      this.data = [];
      this.loaded = true;
      return this.data;
    }
  }

  async save() {
    try {
      const dataDir = path.join(__dirname, 'data');
      const filePath = path.join(dataDir, this.filename);
      await fs.writeFile(filePath, JSON.stringify(this.data, null, 2));
    } catch (error) {
      console.error(`Error saving data to ${this.filename}:`, error);
      throw error;
    }
  }

  async ensureLoaded() {
    if (!this.loaded) {
      await this.load();
    }
  }

  async insert(item) {
    await this.ensureLoaded();
    // Generate a unique ID if not present
    if (!item._id) {
      item._id = Date.now().toString() + Math.random().toString(36).substring(2, 15);
    }
    // Add createdAt if not present
    if (!item.createdAt) {
      item.createdAt = new Date().toISOString();
    }
    this.data.push(item);
    await this.save();
    return item;
  }

  async findById(id) {
    await this.ensureLoaded();
    return this.data.find(item => item._id === id) || null;
  }

  async find(query = {}) {
    await this.ensureLoaded();
    return this.data.filter(item => {
      // Check if all query conditions match
      for (const [key, value] of Object.entries(query)) {
        // Handle special query operators like $regex
        if (key === '$and') {
          if (!value.every(subQuery => this.matchQuery(item, subQuery))) {
            return false;
          }
        } else if (key === '$or') {
          if (!value.some(subQuery => this.matchQuery(item, subQuery))) {
            return false;
          }
        } else if (typeof value === 'object' && value !== null) {
          if (!this.matchComplexCondition(item[key], value)) {
            return false;
          }
        } else if (item[key] !== value) {
          return false;
        }
      }
      return true;
    });
  }

  matchQuery(item, query) {
    for (const [key, value] of Object.entries(query)) {
      if (typeof value === 'object' && value !== null) {
        if (!this.matchComplexCondition(item[key], value)) {
          return false;
        }
      } else if (item[key] !== value) {
        return false;
      }
    }
    return true;
  }

  matchComplexCondition(fieldValue, condition) {
    // Handle special operators
    if (condition.$regex && condition.$options) {
      const regex = new RegExp(condition.$regex, condition.$options);
      return regex.test(fieldValue);
    }
    return false;
  }

  async updateOne(query, update) {
    await this.ensureLoaded();
    const items = await this.find(query);
    if (items.length === 0) {
      return { modifiedCount: 0 };
    }
    
    const item = items[0];
    const index = this.data.findIndex(i => i._id === item._id);
    
    if (update.$set) {
      for (const [key, value] of Object.entries(update.$set)) {
        this.data[index][key] = value;
      }
    }
    
    await this.save();
    return { modifiedCount: 1, updatedItem: this.data[index] };
  }

  async deleteOne(query) {
    await this.ensureLoaded();
    const items = await this.find(query);
    if (items.length === 0) {
      return { deletedCount: 0 };
    }
    
    const item = items[0];
    const index = this.data.findIndex(i => i._id === item._id);
    this.data.splice(index, 1);
    
    await this.save();
    return { deletedCount: 1 };
  }
}

module.exports = DataStore;
